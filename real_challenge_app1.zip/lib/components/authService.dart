import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    clientId: '112253872362-ndshth788tt8ceriq98rd0ah73ro00kt.apps.googleusercontent.com',
    // Web Client ID
    scopes: ['email'],
  );

  // 구글 로그인
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        return null; // 사용자가 로그인 취소한 경우
      }

      final GoogleSignInAuthentication googleAuth = await googleUser
          .authentication;

      final OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCredential =
      await _auth.signInWithCredential(credential);

      // Firestore에 사용자 정보 저장
      if (userCredential.user != null) {
        await saveUserToFirestore(userCredential.user!);
      }

      return userCredential;
    } catch (e) {
      print('Google 로그인 오류: $e');
      return null;
    }
  }

  // 로그아웃
  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
      await _auth.signOut();
    } catch (e) {
      print('로그아웃 오류: $e');
    }
  }

  // Firestore에 사용자 정보 저장
  Future<void> saveUserToFirestore(User user) async {
    final userRef = FirebaseFirestore.instance.collection('users').doc(
        user.uid);

    try {
      await userRef.set({
        'uid': user.uid,
        'name': user.displayName ?? '익명 사용자',
        'email': user.email,
        'photoUrl': user.photoURL ?? '',
        'successCount': FieldValue.increment(0), // 기존 값 유지 or 초기값 설정
        'createdAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      print('Firestore에 사용자 저장 실패: $e');
    }
  }
}