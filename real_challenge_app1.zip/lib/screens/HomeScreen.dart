import 'package:flutter/material.dart';
import 'package:real_challenge_app/screens/LoginScreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'FriendsScreen.dart';    // 친구 창
import 'SettingScreen.dart';  // 설정 창
import 'ChallengeScreen.dart';
import 'RankingScreen.dart';
import 'CommunityScreen.dart';
import 'RewardScreen.dart';
import 'GetChallScreen.dart';
import 'ProfileScreen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  // 각 탭의 화면 정의
  final List<Widget> _screens = [
    ChallengeScreen(),
    RankingScreen(),
    CommunityScreen(),
    RewardScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  // 친구 창 모달
  void _showFriendsModal() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(20),
          height: 300,
          child: FriendsScreen(),
        );
      },
    );
  }

  // 설정 창 모달
  void _showSettingsModal() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(20),
          height: 300,
          child: SettingsScreen(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset(
              'assets/images/meagle0.jpg', // 로고 이미지 경로
              width: 50,
              height: 50,
            ),
            const SizedBox(width: 8.0),
            const Text(
              'RRC',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ],
        ),

        actions: [
          IconButton(
            icon: Icon(Icons.person, color: Colors.black),
            onPressed: _showFriendsModal, // 친구 창 모달
          ),
          IconButton(
            icon: Icon(Icons.settings, color: Colors.black),
            onPressed: _showSettingsModal, // 설정 창 모달
          ),
        ],
      ),

      body: SafeArea(
        child: _screens[_selectedIndex], // 현재 선택된 화면 표시
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '홈',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: '랭킹',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.group),
            label: '커뮤니티',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.card_giftcard),
            label: '리워드',
          ),
        ],
      ),
    );
  }
}

class ChallengeScreen extends StatelessWidget {

  // 사용자 닉네임 가져오기
  Future<String> _fetchNickname() async {
    String userId = FirebaseAuth.instance.currentUser!.uid;

    // Firestore에서 사용자 데이터 가져오기
    DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(userId).get();

    // 닉네임 안전하게 추출
    Map<String, dynamic>? data = userDoc.data() as Map<String, dynamic>?;

    return data != null && data.containsKey('nickname') ? data['nickname'] as String : '익명';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // 상단 배경 및 여우 이미지 섹션
          Stack(
            children: [
              Container(
                height: 360,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/back.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),

        Column(
          children: [
            SizedBox(height: 120),
            Center(
              child: FutureBuilder<String>(
                future: _fetchNickname(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text(
                      '오류 발생',
                      style: TextStyle(fontSize: 18, color: Colors.red),
                    );
                  }

                  String nickname = snapshot.data!;
                  return Column(
                    children: [
                      Text(
                        '$nickname',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          backgroundColor: Colors.white, // 텍스트 배경색
                          decoration: TextDecoration.none, // 추가 효과를 방지
                          shadows: [
                            Shadow(
                              color: Colors.black26, // 그림자 색상
                              blurRadius: 4, // 그림자 흐림 정도
                              offset: Offset(2, 2), // 그림자 위치
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 3),
                      Image.asset(
                        'assets/images/fox.jpg',
                        height: 200,
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ],
     ),

          // 나머지 콘텐츠를 화면에 맞게 확장
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),

                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: GridView.count(
                      crossAxisCount: 3,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      children: [
                        _buildIconButton(
                            context, Icons.perm_contact_cal, '프로필', ProfileScreen()),
                        _buildIconButton(
                            context, Icons.bar_chart, '랭킹', RankingScreen()),
                        _buildIconButton(
                            context, Icons.local_fire_department, '도전',
                            GetChallScreen()),
                        _buildIconButton(
                            context, Icons.group, '커뮤니티', CommunityScreen()),
                        _buildIconButton(context, Icons.card_giftcard, '리워드',
                            RewardScreen()),
                        _buildIconButton(
                            context, Icons.logout, '로그아웃', LoginScreen(),
                            isLogout: true),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20.0),
                    child: Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 350,
                        height: 70,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => GetChallScreen()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.yellow[600],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(70),
                            ),
                            padding: EdgeInsets.symmetric(vertical: 10),
                          ),
                          child: Text(
                            '도전하기!',
                            style: TextStyle(
                              fontSize: 32,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconButton(BuildContext context, IconData icon, String label,
      Widget targetScreen, {bool isLogout = false}) {
    return GestureDetector(
      onTap: () {
        if (isLogout) {
          // 로그아웃 시 기존 화면 스택을 제거하고 로그인 화면으로 이동
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => targetScreen),
                (Route<dynamic> route) => false,
          );
        } else {
          // 일반 화면 이동
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => targetScreen),
          );
        }
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 40,
            backgroundColor: Colors.yellow[600],
            child: Icon(
              icon,
              color: Colors.black,
              size: 40,
            ),
          ),
          SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[800],
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}