import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:math';
import 'ChallengeScreen.dart'; // ChallengeScreen import

class GetChallScreen extends StatefulWidget {
  @override
  _GetChallScreenState createState() => _GetChallScreenState();
}

class _GetChallScreenState extends State<GetChallScreen> {
  @override
  void initState() {
    super.initState();
    _fetchRandomChallenge();
  }

  Future<void> _fetchRandomChallenge() async {
    try {
      final User? user = FirebaseAuth.instance.currentUser;

      if (user == null) return;

      // 사용자가 이미 성공한 챌린지 ID 목록 가져오기
      final completedChallengesSnapshot = await FirebaseFirestore.instance
          .collection('challenges')
          .get();

      final completedChallengeIds = <String>[];

      for (var challengeDoc in completedChallengesSnapshot.docs) {
        final proofDoc = await challengeDoc.reference
            .collection('proof')
            .doc(user.uid)
            .get();

        if (proofDoc.exists && (proofDoc['isCompleted'] ?? false)) {
          completedChallengeIds.add(challengeDoc.id);
        }
      }

      // 모든 챌린지에서 성공하지 않은 챌린지 필터링
      final QuerySnapshot querySnapshot =
      await FirebaseFirestore.instance.collection('challenges').get();

      final availableChallenges = querySnapshot.docs
          .where((doc) => !completedChallengeIds.contains(doc.id))
          .toList();

      await Future.delayed(Duration(seconds: 2)); // 최소 2초 동안 로딩 유지

      if (availableChallenges.isNotEmpty) {
        final randomIndex = Random().nextInt(availableChallenges.length);
        final randomDoc = availableChallenges[randomIndex];
        final randomChallenge = randomDoc.get('title'); // 챌린지 문구
        final challengeType = randomDoc.get('type');    // 챌린지 타입
        final challengeId = randomDoc.id;               // 챌린지 문서 ID
        final keywords = List<String>.from(randomDoc.get('keywords') ?? []); // 키워드 리스트

        // proof 서브 컬렉션에 인증 데이터 추가
        await FirebaseFirestore.instance
            .collection('challenges')
            .doc(challengeId)
            .collection('proof')
            .doc(user.uid)
            .set({
          'isCompleted': false,
          'timestamp': FieldValue.serverTimestamp(),
          'value': '',
        });

        // ChallengeScreen으로 이동하면서 데이터 전달
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ChallengeScreen(
              challengeMessage: randomChallenge,
              challengeType: challengeType,
              keywords: keywords,
              challengeId: challengeId,
              userId: user.uid,
            ),
          ),
        );
      } else {
        // 모든 챌린지를 이미 완료한 경우
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ChallengeScreen(
              challengeMessage: '모든 챌린지를 완료했습니다!',
              challengeType: 'none',
              keywords: [],
              challengeId: '',
              userId: '',
            ),
          ),
        );
      }
    } catch (e) {
      await Future.delayed(Duration(seconds: 2));
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ChallengeScreen(
            challengeMessage: '오류가 발생했습니다.',
            challengeType: 'error',
            keywords: [],
            challengeId: '',
            userId: '',
          ),
        ),
      );
      print('Error fetching challenge: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/meagle2.jpg', // 로고 이미지 경로
              height: 300,
              width: 225,
            ),
            Text(
              '챌린지 불러오는 중...',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            CircularProgressIndicator(), // 로딩 애니메이션
          ],
        ),
      ),
    );
  }
}
