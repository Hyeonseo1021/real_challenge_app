import 'package:flutter/material.dart';
import 'PhotoCertificationScreen.dart';
import 'TextCertificationScreen.dart';
import 'StepCertificationScreen.dart';

class ChallengeScreen extends StatelessWidget {
  final String challengeMessage;
  final String challengeType;
  final List<String> keywords;
  final String challengeId;
  final String userId;

  const ChallengeScreen({
    Key? key,
    required this.challengeMessage,
    required this.challengeType,
    required this.keywords,
    required this.challengeId,
    required this.userId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset(
              'assets/images/meagle0.jpg',
              width: 50,
              height: 50,
            ),
            const SizedBox(width: 8.0),
            const Text(
              'RRC',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              '챌린지',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 50.0),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.yellow[600],
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Text(
                challengeMessage, // 전달받은 챌린지 메시지 표시
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 24.0),
            Center(
              child: Image.asset(
                'assets/images/meagle2.jpg',
                width: 250,
                height: 250,
              ),
            ),
            const SizedBox(height: 24.0),
            ElevatedButton(
              onPressed: () {
                if (challengeType == 'photo') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PhotoCertificationScreen(
                        keywords: keywords,
                        challengeId: challengeId,
                        userId: userId,
                      ),
                    ),
                  );
                } else if (challengeType == 'text') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TextCertificationScreen(
                        keywords: keywords,
                        challengeId: challengeId,
                        userId: userId,
                      ),
                    ),
                  );
                } else if (challengeType == 'steps') {
                  // 걸음 수 챌린지일 때만 목표 걸음 수 추출
                  final targetSteps = _extractTargetSteps(keywords);

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StepCertificationScreen(
                        challengeId: challengeId,
                        userId: userId,
                        targetSteps: targetSteps,
                      ),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('알 수 없는 챌린지 타입입니다.')),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellow[600],
                padding: EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: Text(
                '인증 시작',
                style: TextStyle(fontSize: 24, color: Colors.black),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 키워드에서 목표 걸음 수를 추출하는 함수
  int _extractTargetSteps(List<String> keywords) {
    for (var keyword in keywords) {
      if (RegExp(r'^\d+$').hasMatch(keyword)) {
        return int.parse(keyword);
      }
    }
    // 기본 목표 걸음 수 (예: 5000걸음)
    return 5000;
  }
}
