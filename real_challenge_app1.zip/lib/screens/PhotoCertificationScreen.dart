import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:real_challenge_app/screens/FailScreen.dart';
import 'package:real_challenge_app/screens/SuccessScreen.dart';

class PhotoCertificationScreen extends StatefulWidget {
  final List<String> keywords;
  final String challengeId;
  final String userId;

  const PhotoCertificationScreen({
    Key? key,
    required this.keywords,
    required this.challengeId,
    required this.userId,
  }) : super(key: key);

  @override
  _PhotoCertificationScreenState createState() => _PhotoCertificationScreenState();
}

class _PhotoCertificationScreenState extends State<PhotoCertificationScreen> {
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  final ImageLabeler _labeler = GoogleMlKit.vision.imageLabeler();
  String _recognizedLabels = '';

  // 이미지 선택 및 라벨 인식
  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });

      await _labelImage(File(pickedFile.path));
    }
  }

  // 이미지 라벨링 및 키워드 검사
  Future<void> _labelImage(File image) async {
    final inputImage = InputImage.fromFile(image);
    final labels = await _labeler.processImage(inputImage);

    setState(() {
      if (labels.isNotEmpty) {
        _recognizedLabels = labels.map((label) => label.label).join(', ');

        // 키워드와 라벨 비교
        if (labels.any((label) =>
            widget.keywords.any((keyword) => label.label.toLowerCase().contains(keyword.toLowerCase())))) {
          _completeCertification();
          _showSuccessDialog();
        } else {
          _showErrorDialog('기대하는 키워드가 사진에 포함되지 않았습니다.');
        }
      } else {
        _recognizedLabels = '라벨을 인식할 수 없습니다.';
        _showErrorDialog('라벨을 인식할 수 없습니다.');
      }
    });
  }

  // Firestore에 인증 상태 업데이트
  Future<void> _completeCertification() async {
    try {
      // 인증 완료 상태 업데이트
      await FirebaseFirestore.instance
          .collection('challenges')
          .doc(widget.challengeId)
          .collection('proof')
          .doc(widget.userId)
          .set({
        'isCompleted': true,
        'type': 'photo',
        'timestamp': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      // 사용자의 successCount 업데이트
      final userDocRef = FirebaseFirestore.instance.collection('users').doc(widget.userId);

      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final snapshot = await transaction.get(userDocRef);

        if (snapshot.exists) {
          final currentSuccessCount = snapshot.data()?['successCount'] ?? 0;
          transaction.update(userDocRef, {'successCount': currentSuccessCount + 1});
        } else {
          // 문서가 없는 경우 기본 값으로 초기화 후 업데이트
          transaction.set(userDocRef, {'successCount': 1});
        }
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('사진 인증이 완료되었습니다!')),
      );
    } catch (e) {
      _showErrorDialog('인증 상태 업데이트에 실패했습니다: $e');
    }
  }


  // 성공 다이얼로그
  // 성공 다이얼로그
  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('인증 성공'),
        content: Text('사진에서 키워드가 성공적으로 인식되었습니다!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // 다이얼로그 닫기
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SuccessScreen()),
              );
            },
            child: Text('확인'),
          ),
        ],
      ),
    );
  }

// 에러 다이얼로그
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('인증 실패'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // 다이얼로그 닫기
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => FailScreen()),
              );
            },
            child: Text('확인'),
          ),
        ],
      ),
    );
  }


  @override
  void dispose() {
    _labeler.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('사진 인증')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _imageFile == null
                ? Text('사진을 업로드해주세요.', style: TextStyle(fontSize: 20))
                : Image.file(_imageFile!),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickImage,
              child: Text('사진 선택'),
            ),
            SizedBox(height: 20),

          ],
        ),
      ),
    );
  }
}
