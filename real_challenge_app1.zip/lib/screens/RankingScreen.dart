import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RankingScreen extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    final currentUser = _auth.currentUser;

    if (currentUser == null) {
      return Scaffold(
        appBar: AppBar(title: Text('TOP 100')),
        body: Center(child: Text('로그인이 필요합니다.')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('TOP 100'),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          // Firestore에서 데이터 가져오기
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .where('successCount', isGreaterThan: 0) // successCount가 0보다 큰 문서만 가져오기
                  .orderBy('successCount', descending: true)
                  .limit(100) // TOP 100만 가져오기
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('데이터가 없습니다.'));
                }

                final rankings = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: rankings.length,
                  itemBuilder: (context, index) {
                    final user = rankings[index];
                    final rank = index + 1; // 순위는 1부터 시작
                    final nickname = user['nickname'] ?? '익명 사용자';
                    final count = user['successCount'] ?? 0; // null일 경우 0으로 설정

                    return ListTile(
                      leading: _buildRankIcon(rank),
                      title: Text(
                        nickname,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      trailing: Text(
                        '$count회',
                        style: TextStyle(fontSize: 16),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 내 랭킹 정보 가져오기
          FutureBuilder<DocumentSnapshot>(
            future: FirebaseFirestore.instance
                .collection('users')
                .doc(currentUser.uid)
                .get(),
            builder: (context, snapshot) {
              if (!snapshot.hasData || !snapshot.data!.exists) {
                return Container(
                  color: Colors.grey[200],
                  padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  child: Center(child: Text('내 랭킹 정보를 가져올 수 없습니다.')),
                );
              }

              final currentUserData = snapshot.data!.data() as Map<String, dynamic>?;
              final nickname = currentUserData?['nickname'] ?? '익명 사용자';
              final successCount = currentUserData?['successCount'] ?? 0;

              // 내 랭킹 계산 (Firestore 전체 조회가 필요)
              return StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .orderBy('successCount', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Container(
                      color: Colors.grey[200],
                      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                      child: Center(child: Text('랭킹 정보를 가져올 수 없습니다.')),
                    );
                  }

                  final allUsers = snapshot.data!.docs;
                  int myRank = 0; // Default rank is 0
                  int currentUserSuccessCount = 0;

                  // 현재 사용자 가져오기
                  final currentUser = FirebaseAuth.instance.currentUser;

                  try {
                    // 현재 사용자의 successCount를 가져오고 int로 변환
                    for (var doc in allUsers) {
                      if (doc.id == currentUser?.uid) {
                        currentUserSuccessCount = _parseSuccessCount(doc['successCount']);
                        break;
                      }
                    }

                    // successCount를 기준으로 순위 계산
                    myRank = allUsers.where((doc) {
                      final int otherUserSuccessCount = _parseSuccessCount(doc['successCount']);
                      return otherUserSuccessCount > currentUserSuccessCount;
                    }).length ;
                  } catch (e) {
                    print('Error calculating rank: $e');
                  }

                  return Container(
                    color: Colors.grey[200],
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '내 랭킹: ${myRank > 0 ? myRank : '정보 없음'}',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '성공 횟수: $currentUserSuccessCount회',
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  );
                },
              );

             },
          ),
        ],
      ),
    );
  }

  // 순위 아이콘 위젯
  Widget _buildRankIcon(int rank) {
    switch (rank) {
      case 1:
        return Icon(Icons.emoji_events, color: Colors.yellow[700], size: 32);
      case 2:
        return Icon(Icons.emoji_events, color: Colors.grey, size: 32);
      case 3:
        return Icon(Icons.emoji_events, color: Colors.brown, size: 32);
      default:
        return CircleAvatar(
          backgroundColor: Colors.grey[300],
          child: Text(
            '$rank',
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
        );
    }
  }
}

// successCount를 안전하게 int로 변환하는 함수
int _parseSuccessCount(dynamic value) {
  if (value is int) {
    return value;
  } else if (value is String) {
    return int.tryParse(value) ?? 0;
  }
  return 0; // 값이 null이거나 예상치 못한 타입일 경우 0 반환
}