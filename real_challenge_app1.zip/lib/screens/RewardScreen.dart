import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(RewardApp());
}

class RewardApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RewardScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RewardScreen extends StatefulWidget {
  @override
  _RewardScreenState createState() => _RewardScreenState();
}

class _RewardScreenState extends State<RewardScreen> {
  bool _isSubmitted = false;
  bool _canSubmit = false;
  bool _isLoading = true;
  User? _currentUser; // 로그인된 사용자 정보

  @override
  void initState() {
    super.initState();
    checkLoggedInUser();
  }

  // 로그인한 사용자 확인
  Future<void> checkLoggedInUser() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        setState(() {
          _currentUser = user;
        });
        await checkSuccessCount(user.uid);
      } else {
        // 로그인 안 된 경우 처리
        print("No user logged in.");
      }
    } catch (e) {
      print("Error fetching user: $e");
    }
  }

  // Firestore에서 successCount 확인
  Future<void> checkSuccessCount(String uid) async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users') // 사용자 컬렉션
          .doc(uid)
          .get();

      if (userDoc.exists) {
        int successCount = userDoc.data()?['successCount'] ?? 0;

        setState(() {
          _canSubmit = successCount >= 10;
          _isLoading = false;
        });
      } else {
        print("User document does not exist.");
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      print("Error fetching successCount: $e");
      setState(() {
        _isLoading = false;
      });
    }
  }

  // 응모 처리 함수
  Future<void> handleSubmission() async {
    if (_currentUser == null) return;

    await FirebaseFirestore.instance.collection('entries').add({
      'userId': _currentUser!.uid,
      'reward': '닌텐도 스위치 OLED 마리오 레드 에디션',
      'timestamp': FieldValue.serverTimestamp(),
    });

    setState(() {
      _isSubmitted = true;
    });

    Future.delayed(Duration(seconds: 3), () {
      setState(() {
        _isSubmitted = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('리워드'),
        centerTitle: true,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _currentUser == null
          ? Center(
        child: Text(
          '로그인이 필요합니다.',
          style: TextStyle(fontSize: 18),
        ),
      )
          : SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Image.asset('assets/images/reward1.jpg', height: 200),
              SizedBox(height: 20),
              Text(
                '닌텐도 스위치 OLED 마리오 레드 에디션',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _canSubmit
                    ? (_isSubmitted ? null : handleSubmission)
                    : null,
                child: Text(_canSubmit ? '응모하기' : '응모 불가'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.lightGreenAccent,
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(
                      horizontal: 40, vertical: 12),
                ),
              ),
              if (_isSubmitted)
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    '응모가 완료되었습니다!',
                    style:
                    TextStyle(fontSize: 16, color: Colors.green),
                  ),
                ),
              if (!_canSubmit)
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    '응모 조건: 챌린지를 10회 이상 성공해야 합니다.',
                    style:
                    TextStyle(fontSize: 14, color: Colors.red),
                  ),
                ),
              SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}
