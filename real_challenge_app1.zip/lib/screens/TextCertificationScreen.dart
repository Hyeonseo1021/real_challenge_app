import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'SuccessScreen.dart';
import 'FailScreen.dart';

class TextCertificationScreen extends StatefulWidget {
  final List<String> keywords;
  final String challengeId;
  final String userId;

  const TextCertificationScreen({
    Key? key,
    required this.keywords,
    required this.challengeId,
    required this.userId,
  }) : super(key: key);

  @override
  _TextCertificationScreenState createState() => _TextCertificationScreenState();
}

class _TextCertificationScreenState extends State<TextCertificationScreen> {
  final TextEditingController _textController = TextEditingController();
  String _inputText = '';

  // 키워드 검증 함수
  void _verifyText() {
    setState(() {
      _inputText = _textController.text;
    });

    if (widget.keywords.any((keyword) => _inputText.toLowerCase().contains(keyword.toLowerCase()))) {
      _completeCertification();
      _showSuccessDialog();
    } else {
      _showErrorDialog('기대하는 키워드가 텍스트에 포함되지 않았습니다.');
    }
  }

  // Firestore에 인증 상태 및 입력 텍스트 업데이트
  Future<void> _completeCertification() async {
    try {
      // 인증 성공 정보를 challenges 컬렉션에 저장
      await FirebaseFirestore.instance
          .collection('challenges')
          .doc(widget.challengeId)
          .collection('proof')
          .doc(widget.userId)
          .set({
        'isCompleted': true,
        'type': 'text',
        'value': _inputText,
        'timestamp': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      // 사용자의 successCount 업데이트 및 텍스트 저장
      final userDocRef = FirebaseFirestore.instance.collection('users').doc(widget.userId);

      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final snapshot = await transaction.get(userDocRef);

        if (snapshot.exists) {
          final currentSuccessCount = snapshot.data()?['successCount'] ?? 0;
          transaction.update(userDocRef, {
            'successCount': currentSuccessCount + 1,
            'recentText': _inputText, // 최근 입력한 텍스트 저장
          });
        } else {
          // 문서가 없는 경우 기본 값으로 초기화 후 저장
          transaction.set(userDocRef, {
            'successCount': 1,
            'recentText': _inputText, // 최근 입력한 텍스트 저장
          });
        }
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('텍스트 인증이 완료되었습니다!')),
      );
    } catch (e) {
      _showErrorDialog('인증 상태 업데이트에 실패했습니다: $e');
    }
  }


  // 성공 다이얼로그
  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('인증 성공'),
        content: Text('입력한 텍스트에 키워드가 성공적으로 포함되었습니다!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SuccessScreen()),
              );
            },
            child: Text('확인'),
          ),
        ],
      ),
    );
  }

  // 에러 다이얼로그
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('인증 실패'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => FailScreen()),
              );
            },
            child: Text('확인'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('텍스트 인증')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _textController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: '인증을 위한 텍스트를 입력하세요.',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _verifyText,
              child: Text('인증하기'),
            ),
          ],
        ),
      ),
    );
  }
}
