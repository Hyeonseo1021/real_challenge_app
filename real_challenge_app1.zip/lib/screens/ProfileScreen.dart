import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final User? currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return Scaffold(
        body: Center(
          child: Text('로그인이 필요합니다.'),
        ),
      );
    }

    final String userId = currentUser.uid;

    return Scaffold(
      appBar: AppBar(
        title: Text('프로필'),
        centerTitle: true,
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
        builder: (context, userSnapshot) {
          if (userSnapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!userSnapshot.hasData || !userSnapshot.data!.exists) {
            return Center(child: Text('사용자 정보를 찾을 수 없습니다.'));
          }

          final userData = userSnapshot.data!.data() as Map<String, dynamic>;

          return SingleChildScrollView(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildProfileInfo(userData),
                SizedBox(height: 24),
                _buildChallengeStats(userData),
                SizedBox(height: 24),
                _buildCompletedChallenges(userId),
                SizedBox(height: 24),
                _buildPostList(userId),
              ],
            ),
          );
        },
      ),
    );
  }

  // 기본 정보 섹션
  Widget _buildProfileInfo(Map<String, dynamic> userData) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundImage: AssetImage('assets/profile_placeholder.png'),
          ),
          SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '닉네임: ${userData['nickname'] ?? '알 수 없음'}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                '이메일: ${userData['email'] ?? '알 수 없음'}',
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              SizedBox(height: 8),

            ],
          ),
        ],
      ),
    );
  }

  // 성공한 챌린지 횟수 섹션
  Widget _buildChallengeStats(Map<String, dynamic> userData) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Text(
        '성공한 챌린지 횟수: ${userData['successCount'] ?? 0}회',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  // 성공한 챌린지 목록 섹션
  Widget _buildCompletedChallenges(String userId) {
    return FutureBuilder<QuerySnapshot>(
      future: FirebaseFirestore.instance.collection('challenges').get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(child: Text('성공한 챌린지가 없습니다.'));
        }

        final challenges = snapshot.data!.docs;

        // 각 챌린지의 proof 서브컬렉션에서 사용자의 성공 여부 확인
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '성공한 챌린지 목록',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            ...challenges.map((challenge) {
              final challengeId = challenge.id;
              final challengeName = challenge['title'] ?? '제목 없음';

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('challenges')
                    .doc(challengeId)
                    .collection('proof')
                    .doc(userId)
                    .get(),
                builder: (context, proofSnapshot) {
                  if (proofSnapshot.connectionState == ConnectionState.waiting) {
                    return SizedBox.shrink(); // 로딩 중에는 아무것도 표시하지 않음
                  }

                  if (proofSnapshot.hasData && proofSnapshot.data!.exists) {
                    final proofData = proofSnapshot.data!.data() as Map<String, dynamic>;
                    final isCompleted = proofData['isCompleted'] ?? false;

                    if (isCompleted) {
                      return ListTile(
                        title: Text(challengeName),

                      );
                    }
                  }

                  return SizedBox.shrink(); // 성공하지 않은 챌린지는 표시하지 않음
                },
              );
            }).toList(),
          ],
        );
      },
    );
  }


  // 작성한 글 목록 섹션
  Widget _buildPostList(String authorId) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('posts')
          .where('authorId', isEqualTo: authorId)
          .snapshots(),
      builder: (context, postSnapshot) {
        if (postSnapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (!postSnapshot.hasData || postSnapshot.data!.docs.isEmpty) {
          return Center(child: Text('작성한 글이 없습니다.'));
        }

        final posts = postSnapshot.data!.docs;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '작성한 글 목록',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            ...posts.map((post) {
              final postData = post.data() as Map<String, dynamic>;
              return ListTile(
                title: Text(postData['title'] ?? '제목 없음'),
                trailing: IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    try {
                      await post.reference.delete();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('글이 삭제되었습니다.')),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('삭제 실패: $e')),
                      );
                    }
                  },
                ),
              );
            }).toList(),
          ],
        );
      },
    );
  }
}
