import 'package:flutter/material.dart';

class FriendsScreen extends StatelessWidget {
  // 더미 친구 목록 데이터
  final List<Map<String, String>> friends = [
    {'name': '김민수', 'status': '열심히 챌린지 중!'},
    {'name': '이영희', 'status': '오늘도 화이팅!'},
    {'name': '박지훈', 'status': '휴식 중...'},
    {'name': '최수빈', 'status': '새로운 챌린지 시작!'},
    {'name': '홍길동', 'status': '내가 1등할거임!'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('친구 목록'),
        backgroundColor: Colors.green,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: friends.length,
        itemBuilder: (context, index) {
          final friend = friends[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.green[300],
              child: Text(
                friend['name']![0], // 친구 이름의 첫 글자
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(
              friend['name']!,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(friend['status']!),
            trailing: Icon(Icons.chat_bubble_outline, color: Colors.grey),
          );
        },
      ),
    );
  }
}
