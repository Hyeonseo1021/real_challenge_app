import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart'; // 권한 요청 패키지 추가

class StepCertificationScreen extends StatefulWidget {
  final String challengeId;
  final String userId;
  final int targetSteps; // 목표 걸음 수

  const StepCertificationScreen({
    Key? key,
    required this.challengeId,
    required this.userId,
    required this.targetSteps,
  }) : super(key: key);

  @override
  _StepCertificationScreenState createState() => _StepCertificationScreenState();
}

class _StepCertificationScreenState extends State<StepCertificationScreen> {
  late Stream<StepCount> _stepCountStream;
  int _currentSteps = 0;

  @override
  void initState() {
    super.initState();
    _requestPermissionAndStartListening();
  }

  // 권한 요청 후 걸음 수 측정 시작
  Future<void> _requestPermissionAndStartListening() async {
    var status = await Permission.activityRecognition.request();

    if (status.isGranted) {
      _startListening();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('활동 인식 권한이 필요합니다. 설정에서 권한을 허용해주세요.')),
      );
    }
  }

  void _startListening() {
    _stepCountStream = Pedometer.stepCountStream;
    _stepCountStream.listen(_onStepCount).onError(_onError);
  }

  void _onStepCount(StepCount event) {
    setState(() {
      _currentSteps = event.steps;
    });
  }

  void _onError(error) {
    print('걸음 수 측정 오류: $error');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('걸음 수 측정 오류가 발생했습니다.')),
    );
  }

  // Firestore에 인증 상태 업데이트
  Future<void> _completeCertification() async {
    try {
      if (_currentSteps >= widget.targetSteps) {
        await FirebaseFirestore.instance
            .collection('challenges')
            .doc(widget.challengeId)
            .collection('proof')
            .doc(widget.userId)
            .set({
          'isCompleted': true,
          'type': 'steps',
          'value': _currentSteps,
          'timestamp': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        // 사용자의 successCount 업데이트
        final userDocRef = FirebaseFirestore.instance.collection('users').doc(widget.userId);

        await FirebaseFirestore.instance.runTransaction((transaction) async {
          final snapshot = await transaction.get(userDocRef);

          if (snapshot.exists) {
            final currentSuccessCount = snapshot.data()?['successCount'] ?? 0;
            transaction.update(userDocRef, {'successCount': currentSuccessCount + 1});
          } else {
            // 문서가 없는 경우 기본 값으로 초기화 후 업데이트
            transaction.set(userDocRef, {'successCount': 1});
          }
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('걸음 수 인증이 완료되었습니다!')),
        );


        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('아직 목표 걸음 수에 도달하지 않았습니다.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('인증 실패: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('걸음 수 인증')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '현재 걸음 수: $_currentSteps',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              '목표 걸음 수: ${widget.targetSteps}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: _completeCertification,
              child: Text('인증 완료'),
            ),
          ],
        ),
      ),
    );
  }
}
