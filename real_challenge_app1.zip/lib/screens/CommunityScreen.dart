import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'PostDetailScreen.dart';
import 'PostCreationScreen.dart';
import 'package:intl/intl.dart';

class CommunityScreen extends StatelessWidget {
  // 날짜 포맷 함수
  String _formatDate(String isoDate) {
    final date = DateTime.parse(isoDate);
    return DateFormat('yyyy-MM-dd a hh:mm').format(date); // '오전/오후' 형식
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('커뮤니티'),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.search, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('posts').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          final posts = snapshot.data!.docs;

          return ListView.builder(
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index];
              return ListTile(
                leading: post['category'].toString().isNotEmpty
                    ? Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.orange[200],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    post['category'],
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                )
                    : null,
                title: Text(
                  post['title'],
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  '${post['author']} • ${_formatDate(post['date'])}', // 날짜 포맷 적용
                  style: TextStyle(color: Colors.grey[600]),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PostDetailScreen(postId: post.id),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PostCreationScreen()),
          );
        },
        backgroundColor: Colors.green,
        child: Icon(Icons.edit, color: Colors.white),
      ),
    );
  }
}
