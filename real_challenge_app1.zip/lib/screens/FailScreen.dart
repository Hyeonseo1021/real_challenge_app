import 'package:flutter/material.dart';
import 'HomeScreen.dart';
class FailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('챌린지 실패'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 실패 이미지
            Image.asset(
              'assets/images/Failed.jpg', // 이미지 경로
              width: 200,
              height: 200,
            ),
            SizedBox(height: 20),
            // 실패 메시지
            Text(
              '실패...',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HomeScreen()),
                );
                // 공유 기능 또는 다른 액션 추가
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 10),
              ),
              child: Text(
                '홈으로',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
