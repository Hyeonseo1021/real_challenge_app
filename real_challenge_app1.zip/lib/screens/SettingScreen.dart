import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'LoginScreen.dart'; // 로그인 화면 임포트

class SettingsScreen extends StatelessWidget {
  // 로그아웃 처리 함수
  Future<void> _logout(BuildContext context) async {
    try {
      // Firebase Auth 로그아웃
      await FirebaseAuth.instance.signOut();

      // Google 로그인이 활성화된 경우, Google 로그아웃도 함께 수행
      await GoogleSignIn().signOut();

      // 로그아웃 후 로그인 화면으로 이동
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('로그아웃 실패: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('설정'),
      ),
      body: Center(
        child: ElevatedButton.icon(
          onPressed: () => _logout(context),
          icon: Icon(Icons.logout),
          label: Text('로그아웃'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.redAccent,
            foregroundColor: Colors.white,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          ),
        ),
      ),
    );
  }
}
